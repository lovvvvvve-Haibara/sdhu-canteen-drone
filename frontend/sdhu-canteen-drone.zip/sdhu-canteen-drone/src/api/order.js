import http from './http'

// 顾客创建订单
export function createOrder(data) {
  return http.post('/api/orders', data)
}

// 获取订单详情
export function getOrderDetail(orderId) {
  return http.get(`/api/orders/${orderId}`)
}

// 顾客查询自己的订单列表：GET /api/orders/self?userId=&status=&page=&size=
export function listMyOrders(params) {
  return http.get('/api/orders/self', { params })
}

// 顾客取消订单：POST /api/orders/{id}/cancel  body: { reason }
export function cancelOrder(orderId, reason) {
  return http.post(`/api/orders/${orderId}/cancel`, { reason })
}

// 食堂查看本食堂的订单列表：GET /api/orders/by-canteen/{canteenId}
export function listCanteenOrders(params) {
  const { canteenId, ...rest } = params
  return http.get(`/api/orders/by-canteen/${canteenId}`, { params: rest })
}

// 食堂更新订单状态：POST /api/orders/{id}/status?status=...&note=...
export function updateOrderStatus(orderId, status, note) {
  return http.post(`/api/orders/${orderId}/status`, null, {
    params: {
      status,
      note,
    },
  })
}
