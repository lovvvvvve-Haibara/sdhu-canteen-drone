<template>
  <div class="page">
    <el-page-header content="食堂订单管理">
      <template #extra>
        <el-space>
          <el-button @click="fetchData" :loading="loading">刷新</el-button>
        </el-space>
      </template>
    </el-page-header>

    <!-- 筛选区域 -->
    <div class="filter-row">
      <el-select
        v-model="canteenId"
        placeholder="选择食堂"
        style="width: 220px"
        @change="onCanteenChange"
      >
        <el-option
          v-for="c in canteens"
          :key="c.id"
          :label="c.name"
          :value="c.id"
        />
      </el-select>

      <el-select
        v-model="status"
        placeholder="订单状态"
        clearable
        style="width: 220px"
        @change="onFilterChange"
      >
        <el-option label="全部" :value="null" />
        <el-option label="待处理" value="PENDING" />
        <el-option label="已确认" value="CONFIRMED" />
        <el-option label="已打包" value="PACKED" />
        <el-option label="配送中" value="SHIPPED" />
        <el-option label="已送达" value="DELIVERED" />
        <el-option label="已完成" value="COMPLETED" />
        <el-option label="已取消" value="CANCELED" />
      </el-select>
    </div>

    <!-- 订单表格 -->
    <el-table :data="orders" v-loading="loading" border>
      <el-table-column prop="id" label="订单号" width="120" />
      <el-table-column prop="customerName" label="顾客" width="140" />
      <el-table-column prop="canteenName" label="食堂" width="160" />
      <el-table-column prop="firstFoodName" label="主要菜品" />
      <el-table-column prop="amountCent" label="金额(元)" width="120">
        <template #default="{ row }">
          {{ ((row.amountCent || 0) / 100).toFixed(2) }}
        </template>
      </el-table-column>
      <el-table-column prop="status" label="状态" width="130">
        <template #default="{ row }">
          <el-tag>
            {{ row.statusLabel || statusTextMap[row.status] || row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="deliveryMethod" label="配送方式" width="130">
        <template #default="{ row }">
          {{ row.deliveryMethod === 'DRONE' ? '无人机' : '人工/自取' }}
        </template>
      </el-table-column>
      <el-table-column prop="deliveryAddress" label="配送地址" />
      <el-table-column prop="createdAt" label="创建时间" width="180" />
      <!-- 这里以后可以再加“操作列”，比如 确认/打包/发货 等 -->
    </el-table>

    <div class="pagination">
      <el-pagination
        background
        layout="prev, pager, next, jumper"
        :current-page="page + 1"
        :page-size="size"
        :total="total"
        @current-change="onPageChange"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { useUserStore } from '../../stores/user'
import { listCanteens } from '../../api/canteen'
import { listCanteenOrders } from '../../api/order'

const userStore = useUserStore()

const loading = ref(false)
const canteens = ref([])
const canteenId = ref(null)

const orders = ref([])
const page = ref(0)
const size = ref(10)
const total = ref(0)

const status = ref(null)

const statusTextMap = {
  PENDING: '待处理',
  CONFIRMED: '已确认',
  PACKED: '已打包',
  SHIPPED: '配送中',
  DELIVERED: '已送达',
  COMPLETED: '已完成',
  CANCELED: '已取消',
}

const loadCanteens = async () => {
  try {
    const data = await listCanteens({
      page: 0,
      size: 100,
    })
    canteens.value = data.content || []
    if (!canteenId.value && canteens.value.length) {
      canteenId.value = canteens.value[0].id
    }
  } catch (e) {
    ElMessage.error('加载食堂列表失败')
  }
}

const fetchData = async () => {
  if (!userStore.user?.id) {
    ElMessage.error('请先登录')
    return
  }
  if (!canteenId.value) {
    ElMessage.warning('请先选择食堂')
    return
  }

  loading.value = true
  try {
    const data = await listCanteenOrders({
      canteenId: canteenId.value,
      status: status.value || undefined,
      page: page.value,
      size: size.value,
    })
    orders.value = data.content || []
    total.value = data.totalElements || 0
    page.value = data.number || 0
  } finally {
    loading.value = false
  }
}

const onPageChange = (p) => {
  page.value = p - 1
  fetchData()
}

const onCanteenChange = () => {
  page.value = 0
  fetchData()
}

const onFilterChange = () => {
  page.value = 0
  fetchData()
}

onMounted(async () => {
  await loadCanteens()
  await fetchData()
})
</script>

<style scoped>
.page {
  padding: 16px 24px;
}
.filter-row {
  margin: 16px 0;
  display: flex;
  gap: 12px;
  align-items: center;
}
.pagination {
  margin-top: 16px;
  display: flex;
  justify-content: flex-end;
}
</style>
