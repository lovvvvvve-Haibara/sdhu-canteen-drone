<template>
  <el-container class="admin-layout">
    <el-aside width="200px" class="admin-aside">
      <div class="logo">后台管理</div>
      <el-menu
        :default-active="activeMenu"
        class="admin-menu"
        @select="onMenuSelect"
      >
        <el-menu-item index="/admin/orders">
          订单管理
        </el-menu-item>
        <!-- 以后可以继续加
        <el-menu-item index="/admin/canteens">
          食堂管理
        </el-menu-item>
        <el-menu-item index="/admin/menu">
          菜单管理
        </el-menu-item>
        -->
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="admin-header">
        <div class="title">食堂无人机点餐系统 · 管理后台</div>
        <div class="right">
          <span class="user" v-if="userStore.user">
            {{ userStore.user.displayName }}（{{ userStore.user.role }}）
          </span>
          <el-button type="text" @click="goFront">返回前台</el-button>
        </div>
      </el-header>
      <el-main class="admin-main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '../../stores/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const activeMenu = computed(() => {
  // 让菜单和当前路径保持高亮一致
  if (route.path.startsWith('/admin/orders')) return '/admin/orders'
  return route.path
})

const onMenuSelect = (index) => {
  if (index !== route.path) {
    router.push(index)
  }
}

const goFront = () => {
  router.push('/canteens')
}
</script>

<style scoped>
.admin-layout {
  height: 100vh;
}

.admin-aside {
  background: #001529;
  color: #fff;
  display: flex;
  flex-direction: column;
}

.logo {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}

.admin-menu {
  border-right: none;
  flex: 1;
}

.admin-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #ebeef5;
  background: #fff;
}

.admin-header .title {
  font-size: 16px;
  font-weight: 500;
}

.admin-header .right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.admin-header .user {
  color: #606266;
}

.admin-main {
  background: #f5f7fa;
}
</style>
