import { createRouter, createWebHistory } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '../stores/user'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'Login',
      component: () => import('../views/Login.vue'),
      meta: { public: true },
    },
    {
      path: '/',
      redirect: '/canteens',
    },
    {
      path: '/canteens',
      name: 'CanteenList',
      component: () => import('../views/CanteenList.vue'),
    },
    {
      path: '/orders',
      name: 'MyOrders',
      component: () => import('../views/MyOrders.vue'),
    },

    // ================= 管理员后台 =================
    {
      path: '/admin',
      component: () => import('../views/admin/AdminLayout.vue'),
      meta: { requiresAdmin: true },
      children: [
        {
          path: '',
          redirect: '/admin/orders',
        },
        {
          path: 'orders',
          name: 'AdminOrders',
          component: () => import('../views/admin/AdminOrders.vue'),
        },
        // 以后可以继续加：
        // { path: 'canteens', name: 'AdminCanteens', component: () => import('../views/admin/AdminCanteens.vue') },
      ],
    },

    // 兜底
    {
      path: '/:pathMatch(.*)*',
      redirect: '/canteens',
    },
  ],
})

// 全局前置守卫：登录 + 管理员权限
router.beforeEach((to, from, next) => {
  const userStore = useUserStore()

  // 公共页面（登录）直接放行
  if (to.meta.public) {
    return next()
  }

  // 没登录，一律让去登录
  if (!userStore.isLoggedIn) {
    return next({
      path: '/login',
      query: { redirect: to.fullPath },
    })
  }

  // 访问后台路由时，检查角色
  if (to.matched.some((record) => record.meta.requiresAdmin)) {
    const role = userStore.user?.role
    if (role !== 'ADMIN' && role !== 'CANTEEN') {
      ElMessage.error('无权限访问管理员页面')
      return next('/canteens')
    }
  }

  next()
})

export default router
