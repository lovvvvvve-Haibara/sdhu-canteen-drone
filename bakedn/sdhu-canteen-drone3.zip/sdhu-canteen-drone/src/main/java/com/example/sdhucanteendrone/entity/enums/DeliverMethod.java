package com.example.sdhucanteendrone.entity.enums;

public enum DeliverMethod {DRONE, MANUAL
}
