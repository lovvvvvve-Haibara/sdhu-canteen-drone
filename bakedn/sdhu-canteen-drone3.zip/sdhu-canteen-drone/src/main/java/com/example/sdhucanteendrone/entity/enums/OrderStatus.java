package com.example.sdhucanteendrone.entity.enums;

public enum OrderStatus {
    PENDING, CONFIRMED, PACKED, SHIPPED, DELIVERED, COMPLETED, CANCELED
}
