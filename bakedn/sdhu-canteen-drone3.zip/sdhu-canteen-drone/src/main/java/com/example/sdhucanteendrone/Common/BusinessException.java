package com.example.sdhucanteendrone.Common;

public class BusinessException extends RuntimeException {
    public BusinessException(String message) { super(message); }
}
