create definer = root@localhost view v_stats_by_drone as
select `d`.`id`                             AS `drone_id`,
       `d`.`code`                           AS `drone_code`,
       count(`o`.`id`)                      AS `order_cnt`,
       sum((`o`.`status` = 'COMPLETED'))    AS `completed_cnt`,
       coalesce(sum(`o`.`amount_total`), 0) AS `amount_cent`
from (`software_engineering_project`.`drones` `d` left join `software_engineering_project`.`orders` `o`
      on ((`o`.`drone_id` = `d`.`id`)))
group by `d`.`id`, `d`.`code`;

