create definer = root@localhost view v_stats_daily as
select cast(`o`.`created_at` as date)                                                         AS `dt`,
       count(0)                                                                               AS `total_orders`,
       sum((`o`.`status` in ('SHIPPED', 'DELIVERED', 'COMPLETED')))                           AS `shipped_or_later`,
       sum((`o`.`status` = 'COMPLETED'))                                                      AS `completed_orders`,
       round((ifnull((sum((`o`.`status` = 'COMPLETED')) / nullif(count(0), 0)), 0) * 100), 2) AS `completion_rate_pct`
from `software_engineering_project`.`orders` `o`
group by cast(`o`.`created_at` as date);

