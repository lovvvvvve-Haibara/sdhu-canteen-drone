create definer = root@localhost view v_order_amounts as
select `o`.`id` AS `order_id`, coalesce(sum(`oi`.`subtotal`), 0) AS `amount_total`
from (`software_engineering_project`.`orders` `o` left join `software_engineering_project`.`order_items` `oi`
      on ((`oi`.`order_id` = `o`.`id`)))
group by `o`.`id`;

