create definer = root@localhost view v_stats_by_canteen as
select `c`.`id`                                                                                      AS `canteen_id`,
       `c`.`name`                                                                                    AS `canteen_name`,
       count(`o`.`id`)                                                                               AS `order_cnt`,
       sum((`o`.`status` = 'COMPLETED'))                                                             AS `completed_cnt`,
       round((ifnull((sum((`o`.`status` = 'COMPLETED')) / nullif(count(`o`.`id`), 0)), 0) * 100),
             2)                                                                                      AS `completion_rate_pct`,
       coalesce(sum(`o`.`amount_total`), 0)                                                          AS `amount_cent`
from (`software_engineering_project`.`canteens` `c` left join `software_engineering_project`.`orders` `o`
      on ((`o`.`canteen_id` = `c`.`id`)))
group by `c`.`id`, `c`.`name`;

