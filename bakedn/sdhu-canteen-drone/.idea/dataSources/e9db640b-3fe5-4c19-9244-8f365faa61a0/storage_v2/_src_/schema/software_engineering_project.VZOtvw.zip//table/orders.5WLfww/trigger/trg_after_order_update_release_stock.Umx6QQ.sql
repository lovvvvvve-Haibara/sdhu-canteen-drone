create definer = root@localhost trigger trg_after_order_update_release_stock
    after update
    on orders
    for each row
BEGIN
  IF NEW.status = 'CANCELED' AND OLD.status <> 'CANCELED' THEN
    UPDATE foods f
    JOIN order_items oi ON oi.food_id = f.id AND oi.order_id = NEW.id
       SET f.stock = f.stock + oi.qty;
  END IF;
END;

