create definer = root@localhost trigger trg_after_oi_change_update_amount
    after insert
    on order_items
    for each row
BEGIN
  UPDATE orders o
     JOIN (
       SELECT order_id, COALESCE(SUM(subtotal),0) AS amt FROM order_items WHERE order_id = NEW.order_id
     ) s ON s.order_id = o.id
     SET o.amount_total = s.amt;
END;

