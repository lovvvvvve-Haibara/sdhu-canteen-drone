create definer = root@localhost trigger trg_after_oi_delete_update_amount
    after delete
    on order_items
    for each row
BEGIN
  UPDATE orders o
     LEFT JOIN (
       SELECT order_id, COALESCE(SUM(subtotal),0) AS amt FROM order_items WHERE order_id = OLD.order_id
     ) s ON s.order_id = o.id
     SET o.amount_total = COALESCE(s.amt,0)
   WHERE o.id = OLD.order_id;
END;

