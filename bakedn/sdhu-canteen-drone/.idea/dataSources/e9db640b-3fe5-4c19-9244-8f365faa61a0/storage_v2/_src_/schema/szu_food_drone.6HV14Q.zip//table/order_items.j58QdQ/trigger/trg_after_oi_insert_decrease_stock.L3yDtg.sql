create definer = root@localhost trigger trg_after_oi_insert_decrease_stock
    after insert
    on order_items
    for each row
BEGIN
    UPDATE foods
    SET stock = stock - NEW.qty
    WHERE id = NEW.food_id;
END;

