create definer = root@localhost view v_top_foods as
select `f`.`id`                          AS `id`,
       `f`.`name`                        AS `name`,
       `f`.`canteen_id`                  AS `canteen_id`,
       sum(`oi`.`qty`)                   AS `sold_qty`,
       coalesce(sum(`oi`.`subtotal`), 0) AS `amount_cent`
from ((`software_engineering_project`.`foods` `f` join `software_engineering_project`.`order_items` `oi`
       on ((`oi`.`food_id` = `f`.`id`))) join `software_engineering_project`.`orders` `o`
      on ((`o`.`id` = `oi`.`order_id`)))
group by `f`.`id`, `f`.`name`, `f`.`canteen_id`
order by `sold_qty` desc;

