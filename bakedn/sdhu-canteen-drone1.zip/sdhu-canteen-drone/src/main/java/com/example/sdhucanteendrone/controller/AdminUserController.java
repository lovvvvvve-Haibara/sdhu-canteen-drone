package com.example.sdhucanteendrone.controller;

import com.example.sdhucanteendrone.dto.user.AdminUser;
import com.example.sdhucanteendrone.dto.user.Auth;
import com.example.sdhucanteendrone.dto.user.SelfUser;
import com.example.sdhucanteendrone.service.AdminUserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Validated
@PreAuthorize("hasRole('ADMIN')")
public class AdminUserController {

    private final AdminUserService adminUserService;

    /** 分页查询用户（支持 username/role/status 条件） */
    @GetMapping
    public ResponseEntity<AdminUser.PageResp<Auth.UserBrief>> page(
            @RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="20") int size,
            @RequestParam(required=false) String username,
            @RequestParam(required=false) String role,         // CUSTOMER | CANTEEN | ADMIN
            @RequestParam(required=false) String status        // ACTIVE | LOCKED | DISABLED
    ) {
        return ResponseEntity.ok(adminUserService.pageUsers(page, size, username, role, status));
    }

    /** 获取某个用户详情 */
    @GetMapping("/{id}")
    public ResponseEntity<SelfUser.UserDetail> get(@PathVariable Long id) {
        return ResponseEntity.ok(adminUserService.getUser(id));
    }

    /** 修改用户基本信息（显示名/电话；不含密码与角色） */
    @PutMapping("/{id}")
    public ResponseEntity<SelfUser.UserDetail> update(@PathVariable Long id, @Valid @RequestBody AdminUser.AdminUserUpdateReq req) {
        return ResponseEntity.ok(adminUserService.updateUser(id, req));
    }

    /** 设置用户角色 */
    @PutMapping("/{id}/role")
    public ResponseEntity<SelfUser.UserDetail> setRole(@PathVariable Long id, @RequestBody AdminUser.SetRoleReq req) {
        return ResponseEntity.ok(adminUserService.setRole(id, req.getRole()));
    }

    /** 设置用户状态（封禁/解封/禁用） */
    @PutMapping("/{id}/status")
    public ResponseEntity<SelfUser.UserDetail> setStatus(@PathVariable Long id, @RequestBody AdminUser.SetStatusReq req) {
        return ResponseEntity.ok(adminUserService.setStatus(id, req.getStatus()));
    }

    /** 重置密码 */
    @PutMapping("/{id}/password")
    public ResponseEntity<Void> resetPassword(@PathVariable Long id, @RequestBody AdminUser.ResetPasswordReq req) {
        adminUserService.resetPassword(id, req.getNewPassword());
        return ResponseEntity.noContent().build();
    }

    /** 删除用户（软删可选：此处示例为硬删） */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        adminUserService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
}
