package com.example.sdhucanteendrone.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

public class RegisterReq {
    @NotBlank
    private String username;
    @NotBlank private String displayName;
    @NotBlank private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
