package com.example.sdhucanteendrone.service;

import com.example.sdhucanteendrone.Common.BizException;
import com.example.sdhucanteendrone.dto.CreateOrderDTO;
import com.example.sdhucanteendrone.entity.Order;
import com.example.sdhucanteendrone.entity.OrderItem;
import jakarta.validation.Valid;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface OrderService {
    Long create(Long customerId, CreateOrderDTO dto);
    void updateStatus(Long orderId, String toStatus); // 传枚举名字符串，如 "CANCELED"
    Order getById(Long id);
    List<Order> listAll();

    Long createOrder(Long me, @Valid CreateOrderDTO dto);

    List<Order> listByCustomer(Long me);
    /** 查看订单详情：主表 + 明细 */
    @Transactional(readOnly = true)
    public OrderDetailVO getDetail(Long orderId) ;

    /** 控制器正在使用的嵌套 VO 类型：OrderService.OrderDetailVO */
    public static record OrderDetailVO(Order order, List<OrderItem> items) {}
}
