package com.example.sdhucanteendrone.entity;


//Columns:
//id bigint UN AI PK
//username varchar(64)
//username_lc varchar(64)
//password_hash varchar(255)
//role enum('CUSTOMER','CANTEEN','ADMIN')
//status enum('ACTIVE','LOCKED','DISABLED')
//display_name varchar(100)
//phone varchar(20)
//created_at timestamp
//updated_at timestamp

import java.sql.Timestamp;

public class Employee {

}
