package com.example.sdhucanteendrone.dto;

import jakarta.validation.constraints.NotBlank;
import org.jetbrains.annotations.NotNull;

public class ChangeStatusReq {
    @NotBlank
    private String to;        // 目标状态，如 SHIPPED
    @NotNull
    private Long operator;    // 操作人ID（食堂/管理员）

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public @NotNull Long getOperator() {
        return operator;
    }

    public void setOperator(@NotNull Long operator) {
        this.operator = operator;
    }
}
