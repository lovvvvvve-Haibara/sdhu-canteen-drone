package com.example.sdhucanteendrone.mapper;

import com.example.sdhucanteendrone.entity.Food;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface FoodMapper {
    List<Food> selectAll();
    List<Food> selectByCanteen(@Param("canteenId") Long canteenId);
    Food selectById(@Param("id") Long id);
    int insert(Food food);
    int update(Food food);
    int deleteById(@Param("id") Long id);
}
