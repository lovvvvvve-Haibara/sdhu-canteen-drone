package com.example.sdhucanteendrone.service;

import com.example.sdhucanteendrone.entity.Food;
import java.util.List;

public interface FoodService {
    List<Food> listAll();
    List<Food> listByCanteen(Long canteenId);
    Food getById(Long id);
    Long create(Food food);
    void update(Food food);
    void delete(Long id);
    void setOnShelf(Long id, boolean onShelf);
}
