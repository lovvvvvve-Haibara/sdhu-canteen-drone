package com.example.sdhucanteendrone.entity;

import lombok.Data;

@Data
public class OrderItem {
    private Long id;
    private Long orderId;
    private Long foodId;
    private String foodName;
    private Integer unitPrice;
    private Integer qty;
}
