package com.example.sdhucanteendrone.dto.user;

import io.micrometer.common.lang.Nullable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;

public class Auth {
    @Data
    public class LoginReq { @NotBlank
    String username; @NotBlank String password; }
    @Data public class RegisterReq {
        @NotBlank String username;              // 学号/工号，全局唯一
        @NotBlank String password;
        @NotBlank String displayName;
        @Pattern(regexp="^\\+?[0-9\\-]{6,20}$") @Nullable
        String phone;
    }
    @Data @AllArgsConstructor
    public class TokenResp { String token; long expiresInSeconds; }
    @Data @AllArgsConstructor public class UserBrief {
        Long id; String username; String displayName; String role; String status;
    }
    @Data @AllArgsConstructor public class LoginResp {
        TokenResp token; UserBrief user;
    }

}
