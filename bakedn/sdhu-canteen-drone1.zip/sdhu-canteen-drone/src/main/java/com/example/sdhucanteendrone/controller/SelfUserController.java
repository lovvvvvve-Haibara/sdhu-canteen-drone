package com.example.sdhucanteendrone.controller;

import com.example.sdhucanteendrone.dto.user.SelfUser;
import com.example.sdhucanteendrone.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users/me")
@RequiredArgsConstructor
@Validated
public class SelfUserController {

    private final UserService userService;

    /** 获取自己的资料 */
    @GetMapping
    public ResponseEntity<SelfUser.UserDetail> me() {
        return ResponseEntity.ok(userService.getCurrentUser());
    }

    /** 修改个人资料（displayName/phone） */
    @PutMapping
    public ResponseEntity<SelfUser.UserDetail> updateProfile(@Valid @RequestBody SelfUser.ProfileUpdateReq req) {
        return ResponseEntity.ok(userService.updateCurrentProfile(req));
    }

    /** 修改密码 */
    @PutMapping("/password")
    public ResponseEntity<Void> changePassword(@Valid @RequestBody SelfUser.PasswordChangeReq req) {
        userService.changePassword(req);
        return ResponseEntity.noContent().build();
    }

    /** 我管理的食堂列表（如是 CANTEEN 账号，可查看所管食堂） */
    @GetMapping("/managed-canteens")
    public ResponseEntity<List<SelfUser.CanteenBrief>> myCanteens() {
        return ResponseEntity.ok(userService.listManagedCanteens());
    }
}
