package com.example.sdhucanteendrone.controller;

import com.example.sdhucanteendrone.Common.BizException;
import com.example.sdhucanteendrone.dto.ChangeStatusReq;
import com.example.sdhucanteendrone.dto.CreateOrderDTO;
import com.example.sdhucanteendrone.dto.LoginReq;
import com.example.sdhucanteendrone.dto.RegisterReq;
import com.example.sdhucanteendrone.entity.Order;
import com.example.sdhucanteendrone.entity.User;
import com.example.sdhucanteendrone.entity.enums.OrderStatus;
import com.example.sdhucanteendrone.service.OrderService;
import com.example.sdhucanteendrone.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Validated
public class ApiController {

    private final UserService userService;
    private final OrderService orderService;

    // ========== 用户相关 ==========

    /** 用户注册（JSON） */
    @PostMapping("/users/register")
    public Map<String, Object> register(@RequestBody @Valid RegisterReq req) {
        Long id = userService.register(req.getUsername(), req.getDisplayName(), req.getPassword());
        return Map.of("id", id, "message", "注册成功");
    }

    /** 用户登录（JSON，使用 Session 维持会话） */
    @PostMapping("/auth/login")
    public Map<String, Object> login(@RequestBody @Valid LoginReq req, HttpSession session) {
        User u = userService.login(req.getUsername(), req.getPassword());

        // ✅ 登录成功后将用户信息放入 Session
        session.setAttribute("uid", u.getId());
        session.setAttribute("username", u.getUsername());
        session.setAttribute("role", u.getRole().name());

        return Map.of(
                "id", u.getId(),
                "username", u.getUsername(),
                "displayName", u.getDisplayName(),
                "role", u.getRole().name(),
                "message", "登录成功"
        );
    }

    /** 退出登录（可选） */
    @PostMapping("/auth/logout")
    public Map<String, Object> logout(HttpSession session) {
        session.invalidate(); // 清空会话
        return Map.of("message", "退出成功");
    }

    // ========== 订单相关 ==========

    /** 从 Session 取当前用户ID，未登录则抛出 401 */
    private Long currentUserId(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session == null) throw BizException.unauthorized("未登录");
        Long uid = (Long) session.getAttribute("uid");
        if (uid == null) throw BizException.unauthorized("未登录");
        return uid;
    }

    /** 创建订单（JSON，用户ID来自 Session） */
    @PostMapping("/orders")
    public Map<String, Object> createOrder(HttpServletRequest req,
                                           @Valid @RequestBody CreateOrderDTO dto) {
        Long me = currentUserId(req);
        Long orderId = orderService.createOrder(me, dto);
        return Map.of("id", orderId, "message", "下单成功");
    }

    /** 我的订单（GET，用户ID来自 Session） */
    @GetMapping("/orders/me")
    public List<Order> myOrders(HttpServletRequest req) {
        Long me = currentUserId(req);
        return orderService.listByCustomer(me);
    }

    /** 修改订单状态（JSON） */
    @PostMapping("/orders/{id}/status")
    public Map<String, Object> changeStatus(@PathVariable Long id,
                                            @RequestBody @Valid ChangeStatusReq req) {
        final OrderStatus target;
        try {
            target = OrderStatus.valueOf(req.getTo());
        } catch (IllegalArgumentException e) {
            throw BizException.badRequest("非法状态: " + req.getTo());
        }
        orderService.updateStatus(id, target.name());
        return Map.of("message", "状态修改成功");
    }

    /** 查看订单详情 */
    @GetMapping("/orders/{id}")
    public OrderService.OrderDetailVO orderDetail(@PathVariable Long id) {
        return orderService.getDetail(id);
    }
}
