package com.example.sdhucanteendrone.entity.enums;

public enum UserStatus {ACTIVE, LOCKED, DISABLED
}
