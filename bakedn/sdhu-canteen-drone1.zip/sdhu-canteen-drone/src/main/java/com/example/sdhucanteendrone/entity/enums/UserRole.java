package com.example.sdhucanteendrone.entity.enums;

public enum UserRole {
    CUSTOMER,   // 普通顾客
    CANTEEN,    // 食堂管理员
    ADMIN       // 系统管理员
}
