package com.example.sdhucanteendrone.service;

import com.example.sdhucanteendrone.entity.Employee;
import com.example.sdhucanteendrone.entity.User;
import com.example.sdhucanteendrone.mapper.EmployeeMapper;
import com.example.sdhucanteendrone.mapper.UserMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Resource
    private UserMapper userMapper;

    public List<User> selectAll() {
        return userMapper.selectAll();

    }
}
