package com.example.sdhucanteendrone.repository;

import com.example.app.domain.CanteenManager;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CanteenManagerRepository extends JpaRepository<CanteenManager, Long> {
    List<CanteenManager> findByUserId(Long userId);
}