package com.example.sdhucanteendrone.Common;

public class Result {
    private String code;
    private String mes;
    private Object data;

    public static Result success() {
        Result result = new Result();
        result.setCode("200");
        result.setMes("成功");
        return result;
    }

    public static Result success(Object data) {
        Result result = success();
        result.setCode("200");
        result.setMes("成功");
        result.setData(data);
        return result;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }


}
