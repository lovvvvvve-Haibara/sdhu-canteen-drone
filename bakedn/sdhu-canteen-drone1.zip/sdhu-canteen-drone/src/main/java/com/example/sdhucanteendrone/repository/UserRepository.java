package com.example.sdhucanteendrone.repository;


import com.example.sdhucanteendrone.entity.User;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsernameLc(String usernameLc);
    boolean existsByUsernameLc(String usernameLc);
}
