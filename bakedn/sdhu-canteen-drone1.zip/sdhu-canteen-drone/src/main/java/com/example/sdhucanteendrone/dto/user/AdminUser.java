package com.example.sdhucanteendrone.dto.user;

import io.micrometer.common.lang.Nullable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

public class AdminUser {
    @Data
    public class AdminUserUpdateReq {
        @NotBlank
        String displayName;
        @Pattern(regexp="^\\+?[0-9\\-]{6,20}$") @Nullable
        String phone;
    }
    @Data public class SetRoleReq { @Pattern(regexp="CUSTOMER|CANTEEN|ADMIN") String role; }   // 与枚举一致
    @Data public class SetStatusReq { @Pattern(regexp="ACTIVE|LOCKED|DISABLED") String status; } // 与枚举一致
    @Data public class ResetPasswordReq { @NotBlank String newPassword; }

    @Data @AllArgsConstructor
    public class PageResp<T> {
        List<T> content; long totalElements; int totalPages; int page; int size;
    }

}
