package com.example.sdhucanteendrone.service.impl;

import com.example.sdhucanteendrone.Common.BizException;
import com.example.sdhucanteendrone.Common.BusinessException;
import com.example.sdhucanteendrone.dto.CreateOrderDTO;
import com.example.sdhucanteendrone.entity.Food;
import com.example.sdhucanteendrone.entity.Order;
import com.example.sdhucanteendrone.entity.OrderItem;
import com.example.sdhucanteendrone.entity.enums.DeliverMethod;
import com.example.sdhucanteendrone.entity.enums.OrderStatus;
import com.example.sdhucanteendrone.mapper.FoodMapper;
import com.example.sdhucanteendrone.mapper.OrderItemMapper;
import com.example.sdhucanteendrone.mapper.OrderMapper;
import com.example.sdhucanteendrone.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;

import static com.example.sdhucanteendrone.entity.enums.DeliverMethod.DRONE;
import static com.example.sdhucanteendrone.entity.enums.OrderStatus.PENDING;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderMapper orderMapper;
    private final OrderItemMapper orderItemMapper;
    private final FoodMapper foodMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long create(Long customerId, CreateOrderDTO dto) {
        // 1) 建订单（状态与配送方式你可按需传入，这里最小实现）
        Order order = new Order();
        order.setCustomerId(customerId);
        order.setCanteenId(dto.getCanteenId());
        order.setStatus(PENDING);          // 若你的Mapper用枚举，改成枚举类型
        order.setDeliverMethod(DRONE);     // 同上
        order.setDeliveryAddress(dto.getDeliveryAddress());
        orderMapper.insert(order); // 回写 id

        // 2) 校验并准备明细（库存与总金额交给 DB 触发器）
        List<OrderItem> toSave = new ArrayList<>();
        for (var it : dto.getItems()) {
            Food f = foodMapper.selectById(it.getFoodId());
            if (f == null || !Boolean.TRUE.equals(f.getOnShelf()))
                throw new BusinessException("商品不可用或已下架: " + it.getFoodId());

            OrderItem oi = new OrderItem();
            oi.setOrderId(order.getId());
            oi.setFoodId(f.getId());
            oi.setFoodName(f.getName());
            oi.setUnitPrice(f.getPriceCent());
            oi.setQty(it.getQty());
            toSave.add(oi);
        }
        if (!toSave.isEmpty()) orderItemMapper.insertBatch(toSave);

        // 3) 这里可选写一条 order_status_events（若你有该表）

        return order.getId();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatus(Long orderId, String toStatus) {
        // 取消时触发器回滚库存；其他状态普通更新
        if (orderMapper.selectById(orderId) == null) throw new BusinessException("订单不存在");
        orderMapper.updateStatus(orderId, toStatus);
        // 可选：写 order_status_events
    }

    @Override @Transactional(readOnly = true)
    public Order getById(Long id) {
        var o = orderMapper.selectById(id);
        if (o == null) throw new BusinessException("订单不存在");
        return o;
    }

    @Override @Transactional(readOnly = true)
    public List<Order> listAll() {
        return orderMapper.selectAll();
    }



    /**
     * 创建订单
     * 约定：库存扣减 & 订单总价由数据库触发器完成
     */
    @Transactional
    public Long createOrder(Long me, @Valid CreateOrderDTO dto) {
        // 1) 建主单
        var o = new Order();
        o.setCustomerId(me);
        o.setCanteenId(dto.getCanteenId());
        o.setDeliverMethod(DeliverMethod.DRONE);  // 如需手动配送可改成前端传值
        o.setDeliveryAddress(dto.getDeliveryAddress());
        o.setStatus(OrderStatus.PENDING);
        orderMapper.insert(o); // useGeneratedKeys 回写 id

        // 2) 明细校验并入库（触发器会扣库存 & 刷新 amount_total_cent）
        for (var it : dto.getItems()) {
            var f = foodMapper.selectById(it.getFoodId());
            if (f == null) {
                throw BizException.badRequest("菜品不存在: " + it.getFoodId());
            }
            if (Boolean.FALSE.equals(f.getOnShelf())) {
                throw BizException.badRequest("菜品未上架: " + f.getName());
            }

            var item = new OrderItem();
            item.setOrderId(o.getId());
            item.setFoodId(f.getId());
            item.setFoodName(f.getName());
            item.setUnitPrice(f.getPriceCent());
            item.setQty(it.getQty());
            orderItemMapper.insert(item);
        }

        // 3)（可选）写入 order_status_events：PENDING
        return o.getId();
    }

    /**
     * 我的订单列表（倒序）
     * 说明：如果你的 OrderMapper 已有分页方法 selectByCustomerId(customerId, offset, limit)，
     * 这里给一个“全量/前 N 条”的简单实现。需要分页时，调用你已有的分页方法即可。
     */
    @Transactional(readOnly = true)
    public List<Order> listByCustomer(Long me) {
        // ✅ 方式 B：用分页方法取前 N 条（例如 1000 条，够用就行；需要严格分页请用分页接口）
        int limit = 1000;
        return orderMapper.selectByCustomerId(me, 0, limit);
    }

    @Transactional(readOnly = true)
    public OrderDetailVO getDetail(Long orderId) {
        Order o = orderMapper.selectById(orderId);
        if (o == null) {
            throw BizException.notFound("订单不存在");
        }
        List<OrderItem> items = orderItemMapper.listByOrderId(orderId);
        return new OrderDetailVO(o, items);
    }
}
