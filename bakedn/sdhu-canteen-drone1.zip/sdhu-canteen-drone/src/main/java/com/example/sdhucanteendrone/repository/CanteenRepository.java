package com.example.sdhucanteendrone.repository;



public interface CanteenRepository extends JpaRepository<Canteen, Long> { }