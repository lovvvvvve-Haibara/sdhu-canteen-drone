package com.example.sdhucanteendrone.service.impl;

import com.example.sdhucanteendrone.Common.BusinessException;
import com.example.sdhucanteendrone.entity.Food;
import com.example.sdhucanteendrone.mapper.FoodMapper;
import com.example.sdhucanteendrone.service.FoodService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FoodServiceImpl implements FoodService {

    private final FoodMapper foodMapper;

    @Override @Transactional(readOnly = true)
    public List<Food> listAll() { return foodMapper.selectAll(); }

    @Override @Transactional(readOnly = true)
    public List<Food> listByCanteen(Long canteenId) { return foodMapper.selectByCanteen(canteenId); }

    @Override @Transactional(readOnly = true)
    public Food getById(Long id) {
        var f = foodMapper.selectById(id);
        if (f == null) throw new BusinessException("食品不存在");
        return f;
    }

    @Override @Transactional(rollbackFor = Exception.class)
    public Long create(Food food) {
        foodMapper.insert(food);
        return food.getId();
    }

    @Override @Transactional(rollbackFor = Exception.class)
    public void update(Food food) {
        if (food.getId() == null) throw new BusinessException("缺少食品ID");
        if (foodMapper.selectById(food.getId()) == null) throw new BusinessException("食品不存在");
        foodMapper.update(food);
    }

    @Override @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        if (foodMapper.selectById(id) == null) throw new BusinessException("食品不存在");
        foodMapper.deleteById(id);
    }

    @Override @Transactional(rollbackFor = Exception.class)
    public void setOnShelf(Long id, boolean onShelf) {
        var f = getById(id);
        f.setOnShelf(onShelf);
        foodMapper.update(f);
    }
}
