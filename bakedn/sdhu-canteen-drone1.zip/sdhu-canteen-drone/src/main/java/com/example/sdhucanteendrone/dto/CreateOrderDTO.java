package com.example.sdhucanteendrone.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import org.jetbrains.annotations.NotNull;

import java.util.List;

@Data
public class CreateOrderDTO {
    @NotNull
    private Long canteenId;
    @NotBlank private String deliveryAddress;
    @NotEmpty private List<Item> items;

    @Data
    public static class Item {
        @NotNull private Long foodId;
        @Min(1) private int qty;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public @NotNull Long getCanteenId() {
        return canteenId;
    }

    public void setCanteenId(@NotNull Long canteenId) {
        this.canteenId = canteenId;
    }
}
