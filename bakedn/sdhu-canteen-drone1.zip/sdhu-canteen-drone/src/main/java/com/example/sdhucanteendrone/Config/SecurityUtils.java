package com.example.sdhucanteendrone.Config;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;

public class SecurityUtils {
    public static Long currentUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || auth.getPrincipal() == null) return null;
        Object p = auth.getPrincipal();
        // 你可以把 JWT 解析出的 userId 放进 UsernamePasswordAuthenticationToken 的 principal
        if (p instanceof Long) return (Long) p;
        if (p instanceof String && StringUtils.hasText((String) p)) {
            try { return Long.parseLong((String) p); } catch (NumberFormatException ignored) {}
        }
        return null;
    }
}
