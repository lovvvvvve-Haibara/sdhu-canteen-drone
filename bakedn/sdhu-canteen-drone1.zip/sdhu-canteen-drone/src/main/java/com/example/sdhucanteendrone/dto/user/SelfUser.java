package com.example.sdhucanteendrone.dto.user;

import io.micrometer.common.lang.Nullable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;

public class SelfUser {
    @Data
    public class ProfileUpdateReq {
        @NotBlank
        String displayName;
        @Pattern(regexp="^\\+?[0-9\\-]{6,20}$") @Nullable
        String phone;
    }
    @Data public class PasswordChangeReq { @NotBlank String oldPassword; @NotBlank String newPassword; }

    @Data @Builder
    public class UserDetail {
        Long id; String username; String displayName; String role; String status; String phone;
        Instant createdAt; Instant updatedAt;
    }

    @Data @AllArgsConstructor
    public class CanteenBrief { Long id; String name; String location; }

}
