package com.example.sdhucanteendrone.controller;

import com.example.sdhucanteendrone.Common.BizException;
import com.example.sdhucanteendrone.dto.LoginReq;
import com.example.sdhucanteendrone.dto.RegisterReq;
import com.example.sdhucanteendrone.entity.User;
import com.example.sdhucanteendrone.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // 注册
    @PostMapping("/register")
    public ApiResp<?> register(@RequestBody @Valid RegisterReq req) {
        // 让 Bean Validation 兜底字段校验，不再手写 null 判
        Long uid = userService.register(req.getUsername(), req.getDisplayName(), req.getPassword());
        return ApiResp.ok(Map.of("userId", uid, "message", "注册成功"));
    }

    // 登录：创建会话（带会话固定保护）
    @PostMapping("/login")
    public ApiResp<?> login(@RequestBody @Valid LoginReq req, HttpServletRequest request) {
        User u = userService.login(req.getUsername(), req.getPassword());
        if (u == null) {
            throw BizException.unauthorized("用户名或密码错误");
        }
        // 会话固定攻击防护：更换 SessionID（Servlet 3.1+）
        request.changeSessionId();
        HttpSession session = request.getSession(true);
        session.setAttribute("uid", u.getId());
        // 如需把角色放 session，建议限制来源（例如只允许 DB 枚举值）
        session.setAttribute("role", u.getRole() == null ? "USER" : u.getRole());

        return ApiResp.ok(Map.of("message", "登录成功"));
    }

    // 退出登录：销毁会话（幂等）
    @PostMapping("/logout")
    public ApiResp<?> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) session.invalidate();
        return ApiResp.ok(Map.of("message", "已退出"));
    }

    // 当前用户信息（返回脱敏视图对象）
    @GetMapping("/me")
    public ApiResp<UserVO> me(HttpServletRequest req) {
        Long uid = currentUserId(req);
        User u = userService.getById(uid);
        if (u == null) throw BizException.notFound("用户不存在");
        UserVO vo = new UserVO(u.getId(), u.getUsername(), u.getDisplayName(), u.getRole());
        return ApiResp.ok(vo);
    }

    // ========== 辅助：读取当前登录用户ID ==========
    private Long currentUserId(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session == null) throw BizException.unauthorized("未登录");
        Long uid = (Long) session.getAttribute("uid");
        if (uid == null) throw BizException.unauthorized("未登录");
        return uid;
    }
}
