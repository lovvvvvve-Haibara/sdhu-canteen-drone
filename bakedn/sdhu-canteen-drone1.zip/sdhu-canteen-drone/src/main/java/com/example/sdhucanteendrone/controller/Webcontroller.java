package com.example.sdhucanteendrone.controller;

import com.example.sdhucanteendrone.Common.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Webcontroller {

    @GetMapping("result1")
    public Result getResult1() {
        return Result.success();
    }

    @GetMapping("result2")
    public Result getResult2() {
        return Result.success("This is a test");
    }
}
