package com.example.sdhucanteendrone.mapper;

import com.example.sdhucanteendrone.entity.Employee;

import java.util.List;

public interface EmployeeMapper {
    List<Employee> selectAll();
}
