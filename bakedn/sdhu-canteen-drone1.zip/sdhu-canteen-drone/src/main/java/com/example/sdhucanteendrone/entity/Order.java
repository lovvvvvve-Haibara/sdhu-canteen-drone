package com.example.sdhucanteendrone.entity;

import com.example.sdhucanteendrone.entity.enums.DeliverMethod;
import com.example.sdhucanteendrone.entity.enums.OrderStatus;

import java.time.Instant;

public class Order {
    private Long id;
    private Long customerId;
    private Long canteenId;
    private OrderStatus status;
    private DeliverMethod deliverMethod;
    private String deliveryAddress;
    private Long droneId;
    private Integer amountTotalCent; // 由触发器维护
    private Instant createdAt;
    private Instant updatedAt;

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getAmountTotalCent() {
        return amountTotalCent;
    }

    public void setAmountTotalCent(Integer amountTotalCent) {
        this.amountTotalCent = amountTotalCent;
    }

    public Long getDroneId() {
        return droneId;
    }

    public void setDroneId(Long droneId) {
        this.droneId = droneId;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public DeliverMethod getDeliverMethod() {
        return deliverMethod;
    }

    public void setDeliverMethod(DeliverMethod deliverMethod) {
        this.deliverMethod = deliverMethod;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public Long getCanteenId() {
        return canteenId;
    }

    public void setCanteenId(Long canteenId) {
        this.canteenId = canteenId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
