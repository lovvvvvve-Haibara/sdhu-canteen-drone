package com.example.sdhucanteendrone.service;

import com.example.sdhucanteendrone.dto.user.AdminUser;
import com.example.sdhucanteendrone.dto.user.Auth;
import com.example.sdhucanteendrone.dto.user.SelfUser;

public interface AdminUserService {
    AdminUser.PageResp<Auth.UserBrief> pageUsers(int page, int size, String username, String role, String status);
    SelfUser.UserDetail getUser(Long id);
    SelfUser.UserDetail updateUser(Long id, AdminUser.AdminUserUpdateReq req);
    SelfUser.UserDetail setRole(Long id, String role);
    SelfUser.UserDetail setStatus(Long id, String status);
    void resetPassword(Long id, String newPassword);
    void deleteUser(Long id);
}