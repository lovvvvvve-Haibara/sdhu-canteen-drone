package com.example.sdhucanteendrone.mapper;

import com.example.sdhucanteendrone.entity.User;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface UserMapper {
    List<User> selectAll();
    User selectById(@Param("id") Long id);
    // 以小写 username_lc 查询，入参必须是已 toLowerCase 的字符串
    User selectByUsername(@Param("usernameLc") String usernameLc);
    int insert(User user);
    int update(User user);
    int deleteById(@Param("id") Long id);
}
