package com.example.sdhucanteendrone.service.impl;



import com.example.sdhucanteendrone.Config.SecurityUtils;
import com.example.sdhucanteendrone.dto.user.SelfUser;
import com.example.sdhucanteendrone.entity.User;
import com.example.sdhucanteendrone.repository.CanteenManagerRepository;
import com.example.sdhucanteendrone.repository.CanteenRepository;
import com.example.sdhucanteendrone.repository.UserRepository;
import com.example.sdhucanteendrone.service.UserService;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepo;
    private final CanteenManagerRepository cmRepo;
    private final CanteenRepository canteenRepo;
    private final PasswordEncoder passwordEncoder;

    private User mustCurrent() {
        Long uid = SecurityUtils.currentUserId();
        if (uid == null) throw new IllegalStateException("未登录");
        return userRepo.findById(uid).orElseThrow(() -> new IllegalStateException("用户不存在"));
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetail getCurrentUser() {
        Users u = mustCurrent();
        return SelfUser.UserDetail.builder()
                .id(u.getId()).username(u.getUsername()).displayName(u.getDisplayName())
                .role(u.getRole().name()).status(u.getStatus().name())
                .phone(u.getPhone())
                .createdAt(u.getCreatedAt().toInstant())
                .updatedAt(u.getUpdatedAt().toInstant())
                .build();
    }

    @Override
    @Transactional
    public SelfUser.UserDetail updateCurrentProfile(SelfUser.ProfileUpdateReq req) {
        Users u = mustCurrent();
        u.setDisplayName(req.getDisplayName());
        u.setPhone(req.getPhone());
        u.setUpdatedAt(java.sql.Timestamp.from(Instant.now()));
        userRepo.save(u);
        return getCurrentUser();
    }

    @Override
    @Transactional
    public void changePassword(PasswordChangeReq req) {
        Users u = mustCurrent();
        if (!passwordEncoder.matches(req.getOldPassword(), u.getPasswordHash())) {
            throw new IllegalArgumentException("原密码不正确");
        }
        u.setPasswordHash(passwordEncoder.encode(req.getNewPassword()));
        u.setUpdatedAt(java.sql.Timestamp.from(Instant.now()));
        userRepo.save(u);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CanteenBrief> listManagedCanteens() {
        Users u = mustCurrent();
        List<CanteenManager> list = cmRepo.findByUserId(u.getId());
        List<Long> ids = list.stream().map(CanteenManager::getCanteenId).collect(Collectors.toList());
        List<Canteen> cs = ids.isEmpty() ? List.of() : canteenRepo.findAllById(ids);
        return cs.stream()
                .map(c -> new CanteenBrief(c.getId(), c.getName(), c.getLocation()))
                .collect(Collectors.toList());
    }
}
