package com.example.sdhucanteendrone.controller;

import com.example.sdhucanteendrone.dto.LoginReq;
import com.example.sdhucanteendrone.dto.RegisterReq;
import com.example.sdhucanteendrone.dto.user.Auth;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Validated
public class AuthController {

    private final AuthService authService;

    /** 登录，返回JWT 与用户概要 */
    @PostMapping("/login")
    public ResponseEntity<Auth.LoginResp> login(@Valid @RequestBody LoginReq req) {
        return ResponseEntity.ok(authService.login(req));
    }

    /** 注册（默认注册为 CUSTOMER），最少需要 username / password / displayName */
    @PostMapping("/register")
    public ResponseEntity<Auth.UserBrief> register(@Valid @RequestBody RegisterReq req) {
        return ResponseEntity.ok(authService.register(req));
    }

    /** 刷新令牌（可选） */
    @PostMapping("/refresh")
    public ResponseEntity<Auth.TokenResp> refresh(@RequestHeader("Authorization") String bearer) {
        return ResponseEntity.ok(authService.refresh(bearer));
    }

    /** 退出（可选：黑名单/前端删Token） */
    @PostMapping("/logout")
    public ResponseEntity<Void> logout() {
        return ResponseEntity.noContent().build();
    }
}
