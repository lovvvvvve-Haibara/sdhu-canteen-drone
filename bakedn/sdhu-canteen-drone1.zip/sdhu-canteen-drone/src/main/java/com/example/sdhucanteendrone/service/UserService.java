package com.example.sdhucanteendrone.service;

import com.example.sdhucanteendrone.dto.user.SelfUser;
import java.util.List;

public interface UserService {
    SelfUser.UserDetail getCurrentUser();
    SelfUser.UserDetail updateCurrentProfile(SelfUser.ProfileUpdateReq req);
    void changePassword(SelfUser.PasswordChangeReq req);
    List<SelfUser.CanteenBrief> listManagedCanteens();
}
