package com.example.sdhucanteendrone.service.impl;

import com.example.sdhucanteendrone.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;

    @Override
    @Transactional(readOnly = true)
    public LoginResp login(LoginReq req) {
        String ulc = req.getUsername().toLowerCase(Locale.ROOT);
        Users u = userRepo.findByUsernameLc(ulc)
                .orElseThrow(() -> new IllegalArgumentException("用户不存在或密码错误"));

        if (u.getStatus() == Users.Status.DISABLED || u.getStatus() == Users.Status.LOCKED) {
            throw new IllegalStateException("账号不可用");
        }
        if (!passwordEncoder.matches(req.getPassword(), u.getPasswordHash())) {
            throw new IllegalArgumentException("用户不存在或密码错误");
        }
        String token = jwtProvider.generateToken(u.getId(), u.getUsername(), u.getRole().name());
        return new LoginResp(
                new TokenResp(token, jwtProvider.getTtlSeconds()),
                new UserBrief(u.getId(), u.getUsername(), u.getDisplayName(), u.getRole().name(), u.getStatus().name())
        );
    }

    @Override
    @Transactional
    public UserBrief register(RegisterReq req) {
        String ulc = req.getUsername().toLowerCase(Locale.ROOT);
        if (userRepo.existsByUsernameLc(ulc)) {
            throw new IllegalArgumentException("用户名已存在");
        }
        Users u = new Users();
        u.setUsername(req.getUsername());
        u.setUsernameLc(ulc);
        u.setPasswordHash(passwordEncoder.encode(req.getPassword()));
        u.setDisplayName(req.getDisplayName());
        u.setPhone(req.getPhone());
        u.setRole(Users.Role.CUSTOMER);
        u.setStatus(Users.Status.ACTIVE);
        u.setCreatedAt(java.sql.Timestamp.from(Instant.now()));
        u.setUpdatedAt(java.sql.Timestamp.from(Instant.now()));
        userRepo.save(u);

        return new UserBrief(u.getId(), u.getUsername(), u.getDisplayName(), u.getRole().name(), u.getStatus().name());
    }

    @Override
    public TokenResp refresh(String bearerToken) {
        // 这里给出最简策略：前端持有的旧 token 仍有效，则直接基于数据库用户生成新 token。
        // 生产中建议解析旧 token，验证签名和过期，再续发。
        throw new UnsupportedOperationException("未实现：根据你的 JWT 过滤器实现方式来完成刷新逻辑");
    }
}
