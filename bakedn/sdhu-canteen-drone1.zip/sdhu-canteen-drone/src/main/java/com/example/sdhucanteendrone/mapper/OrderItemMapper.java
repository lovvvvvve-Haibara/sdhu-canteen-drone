package com.example.sdhucanteendrone.mapper;

import com.example.sdhucanteendrone.entity.OrderItem;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface OrderItemMapper {
    int insert(OrderItem item);
    int insertBatch(@Param("items") List<OrderItem> items);
    List<OrderItem> listByOrderId(@Param("orderId") Long orderId);
}
