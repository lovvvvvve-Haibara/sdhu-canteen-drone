package com.example.sdhucanteendrone.service;

import com.example.sdhucanteendrone.dto.user.*;

public interface AuthService {
    Auth.LoginResp login(Auth.LoginReq req);
    Auth.UserBrief register(Auth.RegisterReq req);
    Auth.TokenResp refresh(String bearerToken);
}