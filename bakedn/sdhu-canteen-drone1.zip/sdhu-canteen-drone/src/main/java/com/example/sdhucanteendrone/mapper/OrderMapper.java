package com.example.sdhucanteendrone.mapper;

import com.example.sdhucanteendrone.entity.Order;
import com.example.sdhucanteendrone.entity.enums.OrderStatus;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface OrderMapper {
    List<Order> selectAll();
    Order selectById(@Param("id") Long id);
    int insert(Order order);
    int updateStatus(@Param("id") Long id, @Param("status") String status);
    int deleteById(@Param("id") Long id);
    List<Order> selectByCustomerId(@Param("customerId") Long customerId,
                                   @Param("offset") int offset,
                                   @Param("limit") int limit);
    int updateStatus(@Param("id") Long id, @Param("status") OrderStatus status);

}
