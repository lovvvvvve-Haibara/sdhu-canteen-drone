package com.example.sdhucanteendrone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SdhuCanteenDroneApplicationTests {

    @Test
    void contextLoads() {
    }

}
