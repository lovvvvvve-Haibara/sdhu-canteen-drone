package com.example.sdhucanteendrone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication


public class SdhuCanteenDroneApplication {

    public static void main(String[] args) {
        SpringApplication.run(SdhuCanteenDroneApplication.class, args);
    }

}
