package com.example.sdhucanteendrone.entity.enums;

public enum DroneStatus {
    IDLE, IN_MISSION, MAINTENANCE
}
